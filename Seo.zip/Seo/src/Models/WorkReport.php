<?php

namespace Modules\Seo\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class WorkReport extends Model
{
    use HasFactory;

   
    protected $primaryKey='id';
    
    protected $guarded = [
        'id'
    ];

    public $timestamps = false;
    
    public function getFormattedDateAttribute()
    {
        //return $this->created_at->format('Y-m-d');
    }
    
    protected $appends = ['formattedDate'];


    public function getTable(){
        return config('dbtable.seo_work_report');
    }

    
    public function Users()
    {
        return $this->belongsTo(User::class,'user_id','id');
    }

    public function SeoSetting()
    {
        return $this->belongsTo(SeoTask::class,'seo_task_id','id');
    }
    public function SubmissionWebsite()
    {
        return $this->belongsTo(SeoSubmissionWebsites::class,'submission_websites_id','id');
    }
}
