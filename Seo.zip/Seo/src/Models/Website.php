<?php

namespace Modules\Seo\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Country;
use App\Models\Subscription;
use Modules\Seo\Models\SeoWebsiteKeyword;

class Website extends Model
{
    use HasFactory;



    protected $primaryKey = 'id';

    protected $guarded = [
        'id'
    ];

    public $timestamps = false;


    public function getTable()
    {
        return config('dbtable.seo_websites');
    }




    public function Country()
    {
        return $this->belongsTo(Country::class, 'countries_id', 'countries_id');
    }

    public function Website()
    {
        return $this->belongsTo(WorkReport::class, 'website_id', 'website_id');
    }


    public function subscription_details()
    {
        return $this->belongsTo(Subscription::class, 'subscription_id', 'subscription_id');
    }


    public function keyword_info()
    {
        return $this->hasMany(SeoWebsiteKeyword::class,  'website_id', 'id');
    }
}
