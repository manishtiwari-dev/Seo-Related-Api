<?php
namespace Modules\Seo\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SeoSubmissionWebsites extends Model
{
    use HasFactory;


    protected $primarykey='id';
 
    protected $guarded = [
        'id'
    ];
    
    public $timestamps = false;

  
    
 

    public function getTable(){
        return config('dbtable.seo_submission_websites');
    }



    public function SeoSetting()
    {
        return $this->belongsTo(SeoTask::class,'seo_task_id','id');
    }

    public function SeoWebsite()
    {
        return $this->belongsTo(Website::class,'website_id','id');
    }
    
}
