<?php

namespace Modules\Seo\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SeoAssigneWorker extends Model
{
    use HasFactory;


    protected $primarykey = 'id';

    protected $guarded = [
        'id'
    ];


    public $timestamps = false;

    public function getTable()
    {
        return config('dbtable.seo_assigned_worker');
    }
}
