<?php

namespace Modules\Seo\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Seo\Models\SeoTask;
use Modules\Seo\Models\SeoSubmissionWebsites;
use Modules\Seo\Models\Website;
use Modules\Seo\Models\SeoAssigneWorker;

use Auth;
use DB;
use App\Models\User;
use ApiHelper;
use Validator;

class SeoSubmissionController extends Controller
{
    public $page = 'seo_submission_url';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    //This Function is used to show the list
    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $seotasklist = SeoTask::all();
        $seosubmissionwebsites = SeoSubmissionWebsites::all();
        $role = ApiHelper::get_role_from_token($api_token);

        if ($role == "super_admin") {
            $websitelist = Website::get();
        } else {
            $userId = ApiHelper::get_user_id_from_token($api_token);
            $assignlist = SeoAssigneWorker::where('user_id', $userId)->first();
            $websitelist = Website::where('id', $assignlist->website_id)->get();
            // $websitelist = $websitelist->map(function ($data) {
            //     $data->websites = Website::where('id', $data->website_id)->first();
            //     return $data;
            // });
        }







        /*Binding data into a variable*/

        $res = [
            'seotasklist' => $seotasklist,
            'seosubmissionwebsites' => $seosubmissionwebsites,
            'websitelist' => $websitelist,
            'role' => $role
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $api_token = $request->api_token;
        $seotask = SeoTask::all();
        //   $websites = Website::all();


        $role = ApiHelper::get_role_from_token($api_token);

        if ($role == "super_admin") {
            $websites = Website::get();
        } else {
            $userId = ApiHelper::get_user_id_from_token($api_token);
            $assignlist = SeoAssigneWorker::where('user_id', $userId)->first();
            $websites = Website::where('id', $assignlist->website_id)->get();
            // $websitelist = $websitelist->map(function ($data) {
            //     $data->websites = Website::where('id', $data->website_id)->first();
            //     return $data;
            // });
        }


        $res = [
            'seotask' => $seotask,
            'websites' => $websites,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'username' => 'required',
                'website_id' => 'required',
                'password' => 'required',
                'do_follow' => 'required',
            ],
            [

                'username.required' => 'WEBSITE_USERNAME_REQUIRED',
                'website_id.required' => 'WEBSITE_ID_REQUIRED',
                'password.required' => 'WEBSITE_PASSWORD_REQUIRED',
                'password.do_follow' => 'DO_FOLLOW_REQUIRED',

            ]

        );

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());


        $user = User::where('api_token', $request->api_token)->first();

        $website_url = SeoSubmissionWebsites::where('website_url', $request->website_url)->first();

        if ($website_url) {
            return ApiHelper::JSON_RESPONSE(false, [], 'WEBSITE_URL_ALREADY_EXIST');
        }


        $data = SeoSubmissionWebsites::create([
            'website_id' => $request->website_id,
            'seo_task_id' => $request->seo_task_id,
            'website_url' => $request->website_url,
            'username' => $request->username,
            'email' => $request->email,
            'password' => $request->password,
            'dofollow' => $request->do_follow,
            'da' => $request->da,
            'spam_score' => $request->spam_score,
            'status' => 1,
            'created_by' => $user->id,
        ]);



        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_SUBMISSION_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SUBMISSION_ADD');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;

        //$websites = Website::all();
        $seotask = SeoTask::all();
        $seosubmissionwebsites = SeoSubmissionWebsites::find($id);

        $role = ApiHelper::get_role_from_token($api_token);

        if ($role == "super_admin") {
            $websites = Website::get();
        } else {
            $userId = ApiHelper::get_user_id_from_token($api_token);
            $assignlist = SeoAssigneWorker::where('user_id', $userId)->first();
            $websites = Website::where('id', $assignlist->website_id)->get();
        }


        $res = [
            'websites' => $websites,
            'seotask' => $seotask,
            'seosubmissionwebsites' => $seosubmissionwebsites,

        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $id = $request->id;
        $user = User::where('api_token', $request->api_token)->first();

        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'username' => 'required',
                'website_id' => 'required',
                'password' => 'required',
                'do_follow' => 'required'
            ],
            [

                'username.required' => 'WEBSITE_USERNAME_REQUIRED',
                'website_id.required' => 'WEBSITE_ID_REQUIRED',
                'password.required' => 'WEBSITE_PASSWORD_REQUIRED',
                'password.do_follow' => 'DO_FOLLOW_REQUIRED',

            ]

        );


        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());


        $Seowebsites = SeoSubmissionWebsites::withoutGlobalScope('active')->find($id);
        $Seowebsites->website_id = $request->website_id;
        $Seowebsites->seo_task_id = $request->seo_task_id;
        $Seowebsites->website_url = $request->website_url;
        $Seowebsites->username = $request->username;
        $Seowebsites->email = $request->email;
        $Seowebsites->password = $request->password;
        $Seowebsites->dofollow = $request->do_follow;
        $Seowebsites->da = $request->da;
        $Seowebsites->spam_score = $request->spam_score;
        $Seowebsites->updated_by = $user->id;
        $Seowebsites->update();


        if ($Seowebsites) {
            return ApiHelper::JSON_RESPONSE(true, $Seowebsites, 'SUCCESS_SUBMISSION_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SUBMISSION_UPDATE');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {

        $api_token = $request->api_token;
        $id = $request->id;
        if (!empty($id)) {
            $Seowebsites = SeoSubmissionWebsites::where('id', $id)->first();
            if (!empty($id)) {

                $Seowebsites->delete();

                return ApiHelper::JSON_RESPONSE(true, $Seowebsites, 'SUCCESS_SUBMISSION_DELETE');
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'ALREADY_SUBMISSION_DELETE');
            }
        }
    }

    public function getSubmissionUrl(Request $request)
    {
        // return ApiHelper::JSON_RESPONSE(true,$request->all(),'');
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $website_id = $request->website_id;
        $seo_task_id = $request->seo_task_id;
        $seosubmissionwebsites = array();

        if ($request->website_id && ($request->seo_task_id == '0')) {

            $seosubmissionwebsites = DB::table('seo_submission_websites')->select('id', 'website_id', 'seo_task_id', 'website_url', 'username', 'password', 'dofollow', 'created_at', 'status')->where('website_id', $website_id)->where('website_url', 'like', '%' . $request->input_search . '%')->get();
        } else if ($request->seo_task_id && ($request->website_id == '0')) {

            $seosubmissionwebsites = DB::table('seo_submission_websites')->select('id', 'website_id', 'seo_task_id', 'website_url', 'username', 'password', 'dofollow', 'created_at', 'status')->where('seo_task_id', $seo_task_id)->where('website_url', 'like', '%' . $request->input_search . '%')->get();
        } else if (!empty($website_id) && !empty($seo_task_id)) {

            $seosubmissionwebsites = DB::table('seo_submission_websites')->select('id', 'website_id', 'seo_task_id', 'website_url', 'username', 'password', 'dofollow', 'created_at', 'status')->where('website_id', $website_id)->where('seo_task_id', $seo_task_id)->where('website_url', 'like', '%' . $request->input_search . '%')->get();
        }


        $seotasklist = SeoTask::get();
        $Websitelist = Website::get();

        $res = [
            'seotasklist' => $seotasklist,
            'Websitelist' => $Websitelist,
            'seosubmissionwebsites' => $seosubmissionwebsites,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function ChangeSubmissionStatus(Request $request)
    {
        $api_token = $request->api_token;


        $user = SeoSubmissionWebsites::find($request->id);
        $user->status = $request->status;
        $user->update();
        return ApiHelper::JSON_RESPONSE(true, $user, 'SUCCESS_STATUS_UPDATE');
    }
}
