<?php

namespace Modules\Seo\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use App\Models\Subscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Modules\Seo\Models\SeoResult;
use Modules\Seo\Models\SeoTask;
use Carbon\Carbon;
use Modules\Seo\Models\Website;
use App\Models\Country;
use Modules\Seo\Models\SeoMonthlyStrategy;
use App\Models\User;
use Modules\Seo\Models\SeoAssigneWorker;
use Modules\Seo\Models\SeoAssignTask;
use Modules\Seo\Models\SeoWebsiteKeyword;
use Modules\Seo\Models\SeoWebsiteRanking;



class SeoSettingController extends Controller
{
    public $page = 'seo_general_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageremove = 'remove';
    public $pageupdate = 'update';

    //This Function is used to show the list of plan
    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;



        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        //  $web_setting = Subscription::where('industry_id', 1)->where('status', 1)->paginate();

        $web_setting = Website::with('subscription_details')->paginate();
        $seotask = SeoTask::OrderBy('task_priority', 'asc')->paginate();
        $seoresult = SeoResult::where('parent_id', 0)->paginate();

        if (!empty($seoresult)) {
            $seoresult = $seoresult->map(function ($result) {
                $result->child = SeoResult::where('parent_id', $result->id)->get();
                return $result;
            });
        }

        /*Binding data into a variable*/
        $res = [
            'web_setting' => $web_setting,
            'seotask' => $seotask,
            'seoresult' => $seoresult,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function changeWebsiteStatus(Request $request)
    {
        $api_token = $request->api_token;

        $website = Website::where('id', $request->id)->first();
        $website->status = $request->status;
        $website->update();

        return ApiHelper::JSON_RESPONSE(true, $website, 'SUCCESS_STATUS_UPDATE');
    }



    //seotask store
    public function seo_task_store(Request $request)
    {


        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }



        //validation check
        $validator = Validator::make(
            $request->all(),
            [
                'seo_task_title' => 'required',
                'task_priority' => 'required',
            ],
            [

                'seo_task_title.required' => 'SEOTASK_TITLE_REQUIRED',
                'task_priority.required' => 'TASK_PRIORITY_REQUIRED',

            ]

        );


        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }

        $task = SeoTask::where('seo_task_title', $request->seo_task_title)->first();

        if (empty($task)) {
            $data = SeoTask::create([
                'seo_task_title' => $request->seo_task_title,
                'task_priority' => $request->task_priority,
                'task_frequency' => $request->task_frequency,
                'no_of_submission' => $request->no_of_submission,
                'status' => 1,
            ]);
        } else {

            return ApiHelper::JSON_RESPONSE(true, [], 'SEO_TASK_TITLE_EXISTS');
        }

        $data['tab'] = 'task';
        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_SEOTASK_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SEOTASK_ADD');
        }
    }

    public function seo_task_edit(Request $request)
    {

        $api_token = $request->api_token;

        $seotask = SeoTask::find($request->id);

        /*Binding data into a variable*/
        $res = [

            'seotask' => $seotask,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function seo_task_update(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;

        // Validate user page access

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        //validation check
        $validator = Validator::make(
            $request->all(),
            [
                'seo_task_title' => 'required',
                'task_priority' => 'required',
            ],
            [

                'seo_task_title.required' => 'SEO_TASK_TITLE_REQUIRED',
                'task_priority.required' => 'TASK_PRIORITY_REQUIRED',

            ]

        );

        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }
        $data = '';
        $task = SeoTask::where('seo_task_title', $request->seo_task_title)->where('id', '<>', $request->id)->first();

        if (empty($task)) {
            $data = SeoTask::where('id', $request->id)->update([
                'seo_task_title' => $request->seo_task_title,
                'task_priority' => $request->task_priority,
                'task_frequency' => $request->task_frequency,
                'no_of_submission' => $request->no_of_submission,
                'status' => $request->status,

            ]);
        } else {

            return ApiHelper::JSON_RESPONSE(false, [], 'SEO_TASK_TITLE_EXISTS');
        }


        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_SEOTASK_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SEOTASK_UPDATE');
        }
    }

    public function changeTaskStatus(Request $request)
    {

        $api_token = $request->api_token;

        $task = SeoTask::where('id', $request->id)->first();
        $task->status = $request->status;
        $task->update();

        return ApiHelper::JSON_RESPONSE(true, $task, 'SUCCESS_STATUS_UPDATE');
    }

    public function changeTaskDuplicate(Request $request)
    {

        $api_token = $request->api_token;

        $task = SeoTask::where('id', $request->id)->first();
        $task->duplicate = $request->duplicate;
        $task->update();

        return ApiHelper::JSON_RESPONSE(true, $task, 'SUCCESS_DUPLICATE_STATUS_UPDATE');
    }


    public function seo_task_destroy(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;

        $status = SeoTask::destroy($id);
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, $status, 'SUCCESS_SEOTASK_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SEOTASK_DELETE');
        }
    }

    public function websetting_create(Request $request)
    {

        $api_token = $request->api_token;
        $web_setting = Website::all();
        $country_list = Country::all();
        $subslist = Subscription::with('subscriber_business')->where('status', 1)->get();

        $res = [
            'web_setting' => $web_setting,
            'country_list' => $country_list,
            'subslist' => $subslist,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function websetting_store(Request $request)
    {

        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        //validation check
        $validator = Validator::make(
            $request->all(),
            [
                'website_name' => 'required',
                'website_url' => 'required',
                'countries_id' => 'required',
            ],
            [

                'website_name.required' => 'WEBSITE_NAME_REQUIRED',
                'website_url.required' => 'WEBSITE_URL_REQUIRED',
                'countries_id.required' => 'COUNTRIES_ID_REQUIRED',
            ]

        );

        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }

        $data = Website::create([
            'website_name' => $request->website_name,
            'website_url' => $request->website_url,
            'countries_id' => $request->countries_id,
            'subscription_id' => $request->subscription_id,
            'start_date' =>  Carbon::createFromFormat('d/m/Y', $request->start_date)->format('Y-m-d'),
            'status' => 1,
        ]);



        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_WEBSITE_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_WEBSITE_ADD');
        }
    }

    public function websetting_edit(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;

        $web_setting = Website::find($id);
        $country = Country::all();
        $subslist = Subscription::with('subscriber_business')->where('status', 1)->get();


        $res = [
            'web_setting' => $web_setting,
            'country' => $country,
            'subslist' => $subslist,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }



    public function websetting_update(Request $request)
    {

        $id = $request->id;
        //validation check
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        //validation check
        $validator = Validator::make(
            $request->all(),
            [
                'website_name' => 'required',
                'website_url' => 'required',
                'countries_id' => 'required',
            ],
            [

                'website_name.required' => 'WEBSITE_NAME_REQUIRED',
                'website_url.required' => 'WEBSITE_URL_REQUIRED',
                'countries_id.required' => 'COUNTRIES_ID_REQUIRED',

            ]

        );


        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }

        $data = Website::where('id', $id)->update([
            'website_name' => $request->website_name,
            'website_url' => $request->website_url,
            'countries_id' => $request->countries_id,
            'subscription_id' => $request->subscription_id,
            'start_date' => Carbon::createFromFormat('d/m/Y', $request->start_date)->format('Y-m-d'),
            'end_date' => (!empty($request->end_date)) ? Carbon::createFromFormat('d/m/Y', $request->end_date)->format('Y-m-d') : null,
            'status' => $request->status,

        ]);



        // if ($data) {
        return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_WEBSITE_UPDATE');
        // } else {
        // return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_WEBSITE_UPDATE');
        // }

    }


    public function seo_task_create(Request $request)
    {
        $api_token = $request->api_token;
        $seotask = SeoTask::all();

        $res = [
            'seotask' => $seotask,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function seo_result_create(Request $request)
    {

        $api_token = $request->api_token;

        $seoresult = SeoResult::where('parent_id', 0)->get();

        $res = [
            // 'result'=>$result,
            'seoresult' => $seoresult,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function seo_result_store(Request $request)
    {

        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        //validation check
        $validator = Validator::make(
            $request->all(),
            [
                'title_name' => 'required',
            ],
            [

                'title_name.required' => 'TITLE_NAME_REQUIRED',

            ]

        );

        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }


        // if($request->has('parent_id'))
        // {

        //   $dataChild=SeoResult::where('parent_id',$request->parent_id)->count();
        //   $sort_orderChild=$dataChild+1;


        // }




        if ($request->parent_id == '0') {

            $result = SeoResult::where('title_name', $request->title_name)->first();




            if (empty($result)) {

                $data_parent = SeoResult::where('parent_id', 0)->count();

                $sort_order = $data_parent + 1;

                $data = SeoResult::create([
                    'title_name' => $request->title_name,
                    'parent_id' => $request->parent_id ?? 0,
                    'sort_order' => $sort_order,
                    'status' => 1,
                ]);
            } else {

                return ApiHelper::JSON_RESPONSE(true, [], 'TITLE_NAME_EXISTS');
            }
        } else if ($request->parent_id != '0') {



            // $result = SeoResult::where('title_name', $request->title_name)->first();

            // if (empty($result)) {
            //     $title->title_name = $request->title_name;
            //     $title->parent_id = $request->parent_id;
            // } else {

            //     return ApiHelper::JSON_RESPONSE(false, [], 'TITLE_NAME_EXISTS');

            // }


            $dataChild = SeoResult::where('parent_id', $request->parent_id)->count();

            $sort_orderChild = $dataChild + 1;



            $data = SeoResult::create([
                'title_name' => $request->title_name,
                'parent_id' => $request->parent_id ?? 0,
                'status' => 1,
                'sort_order' => $sort_orderChild,

            ]);
        }


        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_SEORESULT_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SEORESULT_ADD');
        }
    }

    public function seo_result_edit(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;

        $section = SeoResult::where('id', $id)->first();
        $seoresult = SeoResult::where('parent_id', 0)->get();

        $res = [
            'section' => $section,
            'seoresult' => $seoresult,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function seo_result_update(Request $request)
    {
        $api_token = $request->api_token;

        //validation page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        //validation check
        $validator = Validator::make(
            $request->all(),
            [
                'title_name' => 'required',
                'parent_id' => 'required',
            ],
            [

                'title_name.required' => 'TITLE_NAME_REQUIRED',
                'parent_id.required' => 'PARENT_ID_REQUIRED',

            ]

        );

        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }

        $title = SeoResult::find($request->id);

        if ($request->parent_id == '1') {

            $result = SeoResult::where('title_name', $request->title_name)->where('id', '<>', $request->id)->first();

            if (empty($result)) {
                $title->title_name = $request->title_name;
                $title->status = $request->status;
                $title->parent_id = $request->parent_id;
            } else {

                return ApiHelper::JSON_RESPONSE(false, [], 'TITLE_NAME_EXISTS');
            }
        } else {

            // $result = SeoResult::where('title_name', $request->title_name)->first();

            // if (empty($result)) {
            //     $title->title_name = $request->title_name;
            //     $title->status = $request->status;
            //     $title->parent_id = $request->parent_id;
            // } else {

            //     return ApiHelper::JSON_RESPONSE(false, [], 'TITLE_NAME_EXISTS');

            // }

            $title->title_name = $request->title_name;
            $title->status = $request->status;
            $title->parent_id = $request->parent_id;
        }

        $title->update();

        if ($title) {
            return ApiHelper::JSON_RESPONSE(true, $title, 'SUCCESS_SEORESULT_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SEORESULT_UPDATE');
        }
    }

    public function changeResultStatus(Request $request)
    {
        $api_token = $request->api_token;

        $website = SeoResult::where('id', $request->result_id)->first();
        $website->status = $request->status;
        $website->update();
        return ApiHelper::JSON_RESPONSE(true, $website, 'SUCCESS_STATUS_UPDATE');
    }


    public function task_priority(Request $request)
    {
        $api_token = $request->api_token;

        $website = SeoTask::where('id', $request->id)->first();
        $website->task_priority = $request->task_priority;
        $website->update();
        return ApiHelper::JSON_RESPONSE(true, $website, 'SUCCESS_TASK_PRIORITY_UPDATE');
    }


    public function task_submission(Request $request)
    {
        $api_token = $request->api_token;

        $website = SeoTask::where('id', $request->id)->first();
        $website->no_of_submission = $request->no_of_submission;
        $website->update();
        return ApiHelper::JSON_RESPONSE(true, $website, 'SUCCESS_TASK_SUBMISSION_UPDATE');
    }




    public function result_sortOrder(Request $request)
    {
        $api_token = $request->api_token;

        $website = SeoResult::where('id', $request->result_id)->first();
        $website->sort_order = $request->sort_order;
        $website->update();
        return ApiHelper::JSON_RESPONSE(true, $website, 'SUCCESS_SORT_ORDER_UPDATE');
    }



    public function seo_result_destroy(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageremove)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        if (SeoResult::where('id', $request->id)->exists()) {
            SeoResult::where('id', $request->id)->delete();
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_SEOTASK_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(true, [], 'ALLREADY_SEOTASK_DELETE');
        }
    }





    public function task_manage(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;

        if ($id) {
            $website_listing = Website::find($id);
            $website_name = $website_listing->website_name;

            //  $seo_task_listing= SeoMonthlyStrategy::with('Seotaskresult')->where('website_id', '=', $website_listing->id)->get();

            $seo_task_listing = SeoTask::where('status', '1')->orderBy('task_priority', 'ASC')->get();

            if (!empty($seo_task_listing)) {
                $seo_task_listing->map(function ($seo) use ($website_listing) {


                    $seo->taskData = SeoMonthlyStrategy::with('Seotaskresult')->where('website_id', '=', $website_listing->id)->where('seo_task_id', '=', $seo->id)->first();


                    // $seo->taskData = !empty($monthly_task) ?  $monthly_task : '' ;
                    return $seo;
                });
            }


            $userlist = User::where('created_by', 1)->get();


            $res = [
                'seo_task_listing' => $seo_task_listing,
                'website_listing' => $website_listing,
                'userlist' => $userlist,

            ];
            return ApiHelper::JSON_RESPONSE(true, $res, '');
        }
    }



    public function keyword_manage(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;

        if ($id) {
            $website_listing = Website::with('keyword_info')->find($request->id);

            if (!empty($website_listing)) {
                $website_listing->keyword = $website_listing->keyword_info()->select('website_url', 'keywords')->get();
            }



            $webName = '';
            if ($request->has('id')) {
                //getting tax_group_name  Name
                $grpName = Website::where('id', $request->id)->first();
                $webName = !empty($grpName) ? $grpName->website_name : '';
            }

            $res = [
                'website_listing' => $website_listing,
                'website_name' => $webName,

            ];
            return ApiHelper::JSON_RESPONSE(true, $res, '');
        }
    }

    public function keyword_update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $website_url = $request->website_url ? $request->website_url : 0;
        $keywords = $request->keywords ? $request->keywords : 0;
        $website_id =  $request->website_id;

        $webKeyword = SeoWebsiteKeyword::where('website_id', $request->website_id)->get();
        //  return ApiHelper::JSON_RESPONSE(true, $request->all(), 'SUCCESS_WEBSITE_KEYWORDS_UPDATE');

        $seoKey = '';
        if (!empty($webKeyword)) {
            foreach ($webKeyword as $Key => $keywordVal) {
                $id = $keywordVal->id;
                $url = "website_url_" . $id;
                $keywords = "keywords_" . $id;
                $website_id = $request->formdata['website_id'];

                //  SeoWebsiteKeyword::where('id', $id)->delete();

                if (isset($request->formdata[$url])  && isset($request->formdata[$keywords])) {

                    // $seoKey = [
                    //     'website_url'   =>   $request->formdata[$url],
                    //     'keywords'   =>   $request->formdata[$keywords],
                    //     'website_id'  =>   $website_id,
                    //     'updated_by' => ApiHelper::get_user_id_from_token($api_token)

                    // ];
                    //    $data = SeoWebsiteKeyword::Create($seoKey);
                    $seoKey =   SeoWebsiteKeyword::updateOrCreate([
                        'website_id'  =>   $website_id,
                        'id' => $id
                    ], [
                        'website_url'   =>   $request->formdata[$url],
                        'keywords'   =>   $request->formdata[$keywords],
                        'website_id'  =>   $website_id,
                        'updated_by' => ApiHelper::get_user_id_from_token($api_token)

                    ]);
                }
            }
        }




        if (!empty($website_url)) {
            foreach ($website_url as $key => $value) {
                $seoKey = [
                    'website_url'   =>  $value ?? 0,
                    'keywords'   =>  $keywords[$key] ?? 0,
                    'website_id'  =>   $website_id,
                    'updated_by' => ApiHelper::get_user_id_from_token($api_token)
                ];
                $data = SeoWebsiteKeyword::Create($seoKey);
            }
        }


        if ($seoKey) {
            return ApiHelper::JSON_RESPONSE(true, $seoKey, 'SUCCESS_WEBSITE_KEYWORDS_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_WEBSITE_KEYWORDS_UPDATE');
        }
    }




    public function web_ranking(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;

        if ($id) {
            $website_listing = Website::find($id);
            $website_name = $website_listing->website_name;
            $elementArray = [];

            //unique rank date list
            $rankDate = SeoWebsiteRanking::orderBy('ranking_date', 'desc')->groupBy('ranking_date')->limit(10)->get();
            //end unique rank date list

            $uniqueDateArray = [];

            if (!empty($rankDate)) {
                foreach ($rankDate as $key => $dates) {
                    $uniqueDateArray[] = $dates->ranking_date;
                }
            }




            $web_keyword_listing = SeoWebsiteKeyword::with(['ranking_info' => function ($query) {
                $query->orderBy('ranking_date', 'desc');
            }])->where('website_id', $id)->get();
            // if (!empty($web_keyword_listing)) {
            //     $web_keyword_listing->map(function ($keyword) use ($website_listing) {

            //         $keyword->ranking_date =  SeoWebsiteRanking::orderBy('ranking_date', 'asc')->groupBy('ranking_date')->limit(10)->having('keyword_id', $keyword->id)->get();

            //         return $keyword;
            //     });
            // }




            //Filter Rank Date List
            $ranklisting = SeoWebsiteRanking::where('website_id', $id)->get();
            if (!empty($ranklisting)) {
                foreach ($ranklisting as $ranklist) {
                    $elementArray[$ranklist->keyword_id][$ranklist->ranking_date] = $ranklist->ranking_position;
                }
            }

            //end Filter Rank Date List


            $res = [
                'web_keyword_listing' => $web_keyword_listing,
                'website_listing' => $website_listing,
                'rankDate' => $rankDate,
                'ranklisting' => $elementArray,
                'web_ranking_date' => $ranklisting,
                'uniqueDateArray' => $uniqueDateArray,
            ];
            return ApiHelper::JSON_RESPONSE(true, $res, '');
        }
    }



    public function web_ranking_update(Request $request)
    {
        $api_token = $request->api_token;
        $seo_web_keyword = SeoWebsiteKeyword::where('website_id', $request->website_id)->get();

        $rankingWeb = '';
        foreach ($seo_web_keyword  as $seo_web_key) {

            //       if ($request->input('ranking_position_' . $seo_web_key->id) != null) {
            $ranking_position = "ranking_position_" . $seo_web_key->id;

            $rankingWeb =  SeoWebsiteRanking::updateOrCreate(
                [
                    'website_id' => $request->website_id,
                    'keyword_id' =>  $seo_web_key->id,
                    'ranking_date' =>  Carbon::createFromFormat('d/m/Y', $request->ranking_date)->format('Y-m-d'),
                ],
                [
                    'ranking_position' => $request->$ranking_position,
                    'ranking_date' =>  Carbon::createFromFormat('d/m/Y', $request->ranking_date)->format('Y-m-d'),
                    'updated_by' => ApiHelper::get_user_id_from_token($api_token)

                ]
            );
            // }
        }

        if ($rankingWeb) {
            return ApiHelper::JSON_RESPONSE(true, $rankingWeb, 'SUCCESS_WEB_RANKING_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_WEB_RANKING_UPDATE');
        }
    }


    public function manage_task_update(Request $request)
    {
        $api_token = $request->api_token;
        $user_id = $request->user_id;


        //  $seo_task_id  = $request->seo_task_id;
        $seo_task_details = SeoTask::where('status', 1)->get();
        $seo_monthly_strategy = SeoMonthlyStrategy::where('status', 1)->where('website_id', $request->website_id)->get();
        $assigned_user = '';
        //  return ApiHelper::JSON_RESPONSE(true, $seo_monthly_strategy, 'SUCCESS_TASK_MANAGE_UPDATE');
        if ($request->has('user_id')) {
            foreach ($user_id as $Key => $Val) {
                foreach ($seo_monthly_strategy as $strategyKey => $monthlyVal) {
                    // $user_id = $request->input('user_id');

                    $assigned_user =  SeoAssigneWorker::updateOrCreate(
                        [
                            'user_id' => $Val,
                            'website_id' =>   $request->website_id,
                        ],
                        [
                            'user_id' => $Val,
                            'website_id' =>   $request->website_id,
                            'assigned_date' => Carbon::now()
                        ]
                    );


                    // SeoAssignTask::updateOrCreate(
                    //     [
                    //         'user_id' => $Val,
                    //         'website_id' =>   $request->website_id,
                    //     ],
                    //     [
                    //         'user_id' => $Val,
                    //         'website_id' =>   $request->website_id,
                    //         'seo_task_id' => $monthlyVal->seo_task_id,
                    //         'assigned_date' => Carbon::now()
                    //     ]
                    // );

                    SeoAssignTask::where('seo_task_id', $monthlyVal->seo_task_id)->where('website_id', $request->website_id)->delete();

                    SeoAssignTask::create(
                        [
                            'user_id' => $Val,
                            'website_id' =>   $request->website_id,
                            'seo_task_id' => $monthlyVal->seo_task_id,
                            'assigned_date' => Carbon::now()
                        ]
                    );
                }
            }
        }



        $mothlyStrategy = '';
        foreach ($seo_task_details  as $seo_task) {


            //     return ApiHelper::JSON_RESPONSE(true, $seo_task->id, 'SUCCESS_TASK_MANAGE_UPDATE');

            if ($request->input('no_of_submission_' . $seo_task->id) != null) {

                $no_of_submission = $request->input('no_of_submission_' . $seo_task->id);


                $mothlyStrategy =  SeoMonthlyStrategy::updateOrCreate(
                    [
                        'website_id' => $request->website_id,
                        'seo_task_id' =>  $seo_task->id,
                    ],
                    [
                        // 'seo_task_id' =>  $seo_task->id,
                        'no_of_submission' => $no_of_submission,

                    ]
                );
            }
        }


        if ($mothlyStrategy) {
            return ApiHelper::JSON_RESPONSE(true, $mothlyStrategy, 'SUCCESS_TASK_MANAGE_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_TASK_MANAGE_UPDATE');
        }
    }

    public function changeTaskManageStatus(Request $request)
    {
        $api_token = $request->api_token;

        $mothly = SeoMonthlyStrategy::where('seo_task_id', $request->id)->first();

        $mothly->status = $request->status;

        $mothly->update();
        return ApiHelper::JSON_RESPONSE(true, $mothly, 'SUCCESS_STATUS_UPDATE');
    }
}
