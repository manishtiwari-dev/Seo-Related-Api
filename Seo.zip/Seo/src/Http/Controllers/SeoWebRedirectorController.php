<?php

namespace Modules\Seo\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use App\Models\User;
use Exception;
use Modules\Seo\Models\SeoWebRedirects;
use Illuminate\Support\Facades\Validator;
use DateTime;
use App\Models\Subscription;
use Modules\Seo\Models\Website;
use Modules\Seo\Models\SeoAssigneWorker;

class SeoWebRedirectorController extends Controller
{

    public $page = 'web_redirects';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        $api_token = $request->api_token;

        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;

        $data_query = SeoWebRedirects::query();

        // attaching query filter by permission(all, added,owned,both)
        $data_query = ApiHelper::attach_query_permission_filter($data_query, $api_token, $this->page, $this->pageview);

        // search
        if (!empty($search))
            $data_query = $data_query->where("redirect_from", "LIKE", "%{$search}%")->OrWhere("redirect_to", "LIKE", "%{$search}%");


        /* Add Start Date Filter  */

        if ($request->has('website')) {
            if (!empty($request->website)) {
                $data_query = $data_query->where('subscription_id', $request->website);
            }
        }



        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;     // apply page logic
        $data_count = $data_query->count(); // get total count
        $data_list = $data_query->skip($skip)->take($perPage)->orderBy('id', 'DESC')->get();

        $data_list = $data_list->map(function ($data) {
            $data->status = ($data->status == 1) ? "1" : "0";
            return $data;
        });

        // $website_list = Website::all();


        $role = ApiHelper::get_role_from_token($api_token);

        if ($role == "super_admin") {
            $website_list = Website::get();
        } else {
            $userId = ApiHelper::get_user_id_from_token($api_token);
            $assignlist = SeoAssigneWorker::where('user_id', $userId)->first();
            $website_list = Website::where('id', $assignlist->website_id)->get();
        }


        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'website_list' => $website_list,
            'website_url' => ApiHelper::getKeySetVal('website_url'),
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function store(Request $request)
    {
        $api_token = $request->api_token;

        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        // //validation check 
        // $validator = Validator::make(
        //     $request->all(),
        //     [
        //         'redirect_from' => 'required',
        //         'redirect_to' => 'required',
        //     ],
        //     [
        //         'redirect_from.required' => 'REDIRECT_FROM_REQUIRED',
        //         'redirect_to.required' => 'REDIRECT_TO_REQUIRED',
        //     ]
        // );
        // if ($validator->fails())
        //     return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $subsExist = SeoWebRedirects::where(['subscription_id' => $request->subscription_id, 'redirect_from' => $request->redirect_from])->first();

        if (!empty($subsExist)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'Already Added');
        } else {
            $Insert = $request->only(['redirect_from', 'redirect_to', 'redirect_type', 'subscription_id']);
            $Insert['created_by'] = User::where('api_token', $request->api_token)->first()->id;

            $res = SeoWebRedirects::create($Insert);

            if ($res)
                return ApiHelper::JSON_RESPONSE(true, $res->id, 'SUCCESS_WEB_REDIRECTOR_ADD');
            else
                return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_WEB_REDIRECTOR_ADD');
        }
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $data_list = SeoWebRedirects::where('id', $request->id)->first();
        $website_list = Website::all();

        $res = [
            'data_list' => $data_list,
            'website_list' => $website_list,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function update(Request $request)
    {
        $api_token = $request->api_token;
        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        // //validation check 
        // $validator = Validator::make(
        //     $request->all(),
        //     [
        //         'redirect_from' => 'required',
        //         'redirect_to' => 'required',
        //     ],
        //     [
        //         'redirect_from.required' => 'REDIRECT_FROM_REQUIRED',
        //         'redirect_to.required' => 'REDIRECT_TO_REQUIRED',
        //     ]
        // );
        // if ($validator->fails())
        //     return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $Insert = $request->only(['redirect_from', 'redirect_to', 'redirect_type']);
        try {
            $res = SeoWebRedirects::where('id', $request->id)->update($Insert);
            return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS_WEB_REDIRECTOR_UPDATE');
        } catch (Exception $e) {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_WEB_REDIRECTOR_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $id = $request->id;
        $status = SeoWebRedirects::where('id', $id)->delete();
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_WEB_REDIRECTOR_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_WEB_REDIRECTOR_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {
        $infoData = SeoWebRedirects::where('id', $request->id)->first();
        $infoData->status = ($infoData->status == 0) ? '1' : '0';
        $infoData->save();
        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }
}
